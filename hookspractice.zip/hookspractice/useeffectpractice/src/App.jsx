import React, { useEffect } from 'react'
import { useState } from 'react';
import axios from "axios";
import './App.css'

function App() {
  //fetch api
  const [Fact,setFact] = useState()
  useEffect(()=>{
    async function generatefacts(){
      let facts = await axios.get("https://meowfacts.herokuapp.com/");
      let finalfact = facts.data.data[0]
      setFact(finalfact)
  
    }
    generatefacts();
  },[])
  
  return (
    <>
    <h1>CatFacts🐈</h1>
    <p>
      {Fact}
    </p>
    </>
  )
  
}

export default App
